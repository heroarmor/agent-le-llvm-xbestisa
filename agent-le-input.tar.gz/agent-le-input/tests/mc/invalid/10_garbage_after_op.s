bestisa.add3 a0, a1, a2, a3, a4
