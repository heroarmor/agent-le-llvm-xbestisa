bestisa.lw a0, a1, a2, a3
