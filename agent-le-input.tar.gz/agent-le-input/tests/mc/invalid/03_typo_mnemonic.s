bestisa.add4 a0, a1, a2, a3
